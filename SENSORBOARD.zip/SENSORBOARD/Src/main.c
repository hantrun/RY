/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* USER CODE BEGIN Includes */
#include "canid.h"
#include "main.h"
#define RPM_TIMEOUT					(float) (1/60)/48						//Minimum rounds per second
#define RAWTOTIME					(float) 1 	//1 is not correct... yet	//Timercounter-realtime(seconds) ratio
#define BYTE1(u)					((uint32_t) u) >> 8;
#define BYTE2(u)					((uint32_t) u) & 0x00ff;

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc2;

CAN_HandleTypeDef hcan1;

TIM_HandleTypeDef htim1;

/* USER CODE BEGIN PV */
CanTxMsgTypeDef txmsg;
CanRxMsgTypeDef rxmsg;
/* Private variables ---------------------------------------------------------*/
uint32_t test=0;
uint32_t ADC1_RAW[9];
uint32_t ADC2_RAW[6];
uint32_t TIMESTAMP_RIGHT, TIMESTAMP_LEFT, COUNT_RIGHT, COUNT_LEFT;
uint32_t ERROR_COUNT_RL[8];
uint32_t ERROR_COUNT_S[7];
struct RL_sensor gas = { CAN_ID_SENSOR_ACC_BRK, 0, 1, 105, 0, 1 }; //gas
struct RL_sensor bremsdruck = { CAN_ID_SENSOR_BRK_BAR, 2, 3, 250, 0, 1 }; //bremsdruck vorne=recht
struct RL_sensor feder_v = { CAN_ID_SENSOR_SUS_MM, 5, 6, 75, 0, 0 }; //feder vorne
struct RL_sensor feder_h = { CAN_ID_SENSOR_SUS_MM, 7, 8, 75, 0, 0 }; //feder hinten
struct S_sensor lenkung = { CAN_ID_SENSOR_STEERING, 2, 0, 0 }; //lenkwinkel done

//temperature sensors
struct S_sensor temp1 = { 0, 0, 0, 0 };
struct S_sensor temp2 = { 0, 1, 0, 0 };
struct S_sensor temp3 = { 0, 2, 0, 0 };
struct S_sensor temp4 = { 0, 3, 0, 0 };
struct S_sensor temp5 = { 0, 4, 0, 0 };
struct S_sensor temp6 = { 0, 5, 0, 0 };

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void Error_Handler(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_CAN1_Init(void);
static void MX_TIM1_Init(void);
static void MX_ADC2_Init(void);

/* USER CODE BEGIN PFP */
void INIT_CONSTANT(uint32_t);
void RPSNull(void);
void Calculate_RPM(void);
void Calculate_BD(struct RL_sensor);
void Calculate_Temp(struct S_sensor);
void Calculate_LW(struct S_sensor);
void Calculate_ACC_BRK(struct RL_sensor, struct RL_sensor, uint32_t[]);
void Calculate_FD(struct RL_sensor, struct RL_sensor);
void Check_PIN(void);


/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */
	hcan1.pTxMsg = &txmsg;
	hcan1.pRxMsg = &rxmsg;
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_CAN1_Init();
  MX_TIM1_Init();
  MX_ADC2_Init();

  /* USER CODE BEGIN 2 */
	 HAL_TIM_Base_Start(&htim1);
  for(int i=0; i<=8;i++){
	  ADC1_RAW[i] = i;
  }
	 HAL_ADC_Start_DMA(&hadc1, (uint32_t *) ADC1_RAW, 9);
	// HAL_ADC_Start_DMA(&hadc2, (uint32_t *) ADC2_RAW, 6);
	 //INIT_CONSTANT(hadc1.Init.Resolution);

//	 hcan1.pTxMsg->IDE = 2;
	 //hcan1.pTxMsg->RTR = CAN_RTR_DATA;
//	 hcan1.pTxMsg->StdId = 0x442;
//	 hcan1.pTxMsg->DLC = 0;
//	 HAL_CAN_Transmit(&hcan1, 100);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
		//RPSNull(); //todo
		//	Calculate_RPM(); //todo
		Check_PIN(); //done
		Calculate_BD(bremsdruck); //done
		Calculate_ACC_BRK(gas, bremsdruck, ADC1_RAW);		//done
		Calculate_FD(feder_v, feder_h); //done
		Calculate_LW(lenkung); //done

//		Calculate_Temp(temp1); //todo
//		Calculate_Temp(temp2); //todo
//		Calculate_Temp(temp3); //todo
//		Calculate_Temp(temp4); //todo
//		Calculate_Temp(temp5); //todo
//		Calculate_Temp(temp6); //todo
		HAL_TIM_Base_Start(&htim1);
		HAL_Delay(1000);
		uint32_t time = __HAL_TIM_GetCounter(&htim1);
	//	uint32_t time = __HAL_TIM_GET_COUNTER(&htim1);
		hcan1.pTxMsg->StdId=200;
		hcan1.pTxMsg->DLC=3;
		hcan1.pTxMsg->Data[0]= time;
		hcan1.pTxMsg->Data[1]= time >> 8;
		hcan1.pTxMsg->Data[2]= time & 0x00ff;
		HAL_CAN_Transmit(&hcan1, 10);
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

	}
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }

  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_8B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 9;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_144CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_5;
  sConfig.Rank = 5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = 6;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_7;
  sConfig.Rank = 7;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = 8;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 9;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

}

/* ADC2 init function */
static void MX_ADC2_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = ENABLE;
  hadc2.Init.ContinuousConvMode = ENABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 6;
  hadc2.Init.DMAContinuousRequests = ENABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_10;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_144CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_11;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_13;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_14;
  sConfig.Rank = 5;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_15;
  sConfig.Rank = 6;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

}

/* CAN1 init function */
static void MX_CAN1_Init(void)
{

  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 2;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SJW = CAN_SJW_1TQ;
  hcan1.Init.BS1 = CAN_BS1_14TQ;
  hcan1.Init.BS2 = CAN_BS2_6TQ;
  hcan1.Init.TTCM = DISABLE;
  hcan1.Init.ABOM = DISABLE;
  hcan1.Init.AWUM = DISABLE;
  hcan1.Init.NART = DISABLE;
  hcan1.Init.RFLM = DISABLE;
  hcan1.Init.TXFP = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }

}

/* TIM1 init function */
static void MX_TIM1_Init(void)
{

  TIM_SlaveConfigTypeDef sSlaveConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_TIM_IC_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }

  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_EXTERNAL1;
  sSlaveConfig.InputTrigger = TIM_TS_ITR0;
  if (HAL_TIM_SlaveConfigSynchronization(&htim1, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
  /* DMA2_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

}

/* USER CODE BEGIN 4 */
/*
 * detects if RPS < Minimum RPS and if no movement at all
 */
void RPSNull(void) {
	if (RPM_TIMEOUT <= __HAL_TIM_GET_COUNTER(&htim1) * RAWTOTIME) {
		TIMESTAMP_RIGHT = 0;
		TIMESTAMP_LEFT = 0;
		COUNT_RIGHT = 0;
		COUNT_LEFT = 0;
		__HAL_TIM_SET_COUNTER(&htim1, 0);
//		HAL_TIM_Base_Stop(&htim1);
//		HAL_TIM_Base_Start(&htim1);

	}
}

/*
 * Save RPM signal
 */
void RPSRoutine(void) {
	if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_6)) {
		TIMESTAMP_RIGHT = __HAL_TIM_GET_COUNTER(&htim1);
		COUNT_RIGHT++;
	} else if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_7)) {
		TIMESTAMP_LEFT = __HAL_TIM_GET_COUNTER(&htim1);
		COUNT_LEFT++;
	}
}

/*
 * Translate RAWDATA to realvalues
 * @param: Sensor
 */
void Calculate_BD(struct RL_sensor sensor) {
	//calculate and send
	if (ADC1_RAW[sensor.CHANNEL_LEFT]) {
		ERROR_COUNT_RL[sensor.CHANNEL_LEFT] = 0;
	}
	if (ADC1_RAW[sensor.CHANNEL_RIGHT]) {
		ERROR_COUNT_RL[sensor.CHANNEL_RIGHT] = 0;
	}
	float right_conv = ADC1_RAW[sensor.CHANNEL_RIGHT] * sensor.CONSTANT;
	float left_conv = ADC1_RAW[sensor.CHANNEL_LEFT] * sensor.CONSTANT;
	hcan1.pTxMsg->StdId = sensor.CAN_ID;
	if (!sensor.RAW) {
		hcan1.pTxMsg->DLC = 4;
	} else {
		hcan1.pTxMsg->DLC = 8;
	}
	hcan1.pTxMsg->Data[0] = BYTE1(left_conv);
	hcan1.pTxMsg->Data[1] = BYTE2(left_conv);
	hcan1.pTxMsg->Data[2] = BYTE1(right_conv);
	hcan1.pTxMsg->Data[3] = BYTE2(right_conv);
	hcan1.pTxMsg->Data[4] = BYTE1(ADC1_RAW[sensor.CHANNEL_LEFT]);
	hcan1.pTxMsg->Data[5] = BYTE2(ADC1_RAW[sensor.CHANNEL_LEFT]);
	hcan1.pTxMsg->Data[6] = BYTE1(ADC1_RAW[sensor.CHANNEL_RIGHT]);
	hcan1.pTxMsg->Data[7] = BYTE2(ADC1_RAW[sensor.CHANNEL_RIGHT]);
	HAL_CAN_Transmit(&hcan1, 10);
}
/*
 * Translate RAWDATA to realvalues
 */
void Calculate_Temp(struct S_sensor sensor) {
//check if sensor is plugged
	if (ADC2_RAW[sensor.CHANNEL]) {
		ERROR_COUNT_S[sensor.CHANNEL] = 0;
	}
	uint32_t temp = ADC2_RAW[sensor.CHANNEL] * sensor.CONSTANT;
	hcan1.pTxMsg->StdId = sensor.CAN_ID;
	hcan1.pTxMsg->DLC = 2;
	hcan1.pTxMsg->Data[0] = temp >> 8;
	hcan1.pTxMsg->Data[1] = temp & 0x00ff;
	HAL_CAN_Transmit(&hcan1, 10);
}
/*
 * Translate steering
 */
void Calculate_LW(struct S_sensor sensor) {
	if (ADC1_RAW[sensor.CHANNEL]) {
		ERROR_COUNT_RL[sensor.CHANNEL] = 0;
	}
	float winkel = ((sensor.MAX * 2) / (hadc1.Init.Resolution ^ 2)) *(ADC1_RAW[sensor.CHANNEL]) - sensor.MAX;
	hcan1.pTxMsg->StdId = sensor.CAN_ID;
	hcan1.pTxMsg->DLC = 4;
	hcan1.pTxMsg->Data[0] = 0;
	hcan1.pTxMsg->Data[1] = 0;
	hcan1.pTxMsg->Data[2] = BYTE1(winkel);
	hcan1.pTxMsg->Data[3] = BYTE2(winkel);
	HAL_CAN_Transmit(&hcan1, 10);
}

/*
 * Calculate RPM
 */
void Calculate_RPM(void) {
	float rps_right = COUNT_RIGHT / (TIMESTAMP_RIGHT * RAWTOTIME );
	float rps_left = COUNT_LEFT / (TIMESTAMP_LEFT * RAWTOTIME );
	hcan1.pTxMsg->StdId = CAN_ID_SENSOR_N_FRONT;
	hcan1.pTxMsg->DLC = 4;
	hcan1.pTxMsg->Data[0] = BYTE1(rps_right * 60);
	hcan1.pTxMsg->Data[1] = BYTE2(rps_right * 60);
	hcan1.pTxMsg->Data[3] = BYTE1(rps_left * 60);
	hcan1.pTxMsg->Data[4] = BYTE2(rps_left * 60);
	HAL_CAN_Transmit(&hcan1, 10);
}
void INIT_CONSTANT(uint32_t resolution) {
	resolution = 2 ^ resolution - 1;
	gas.CONSTANT = gas.MAX / resolution;
	bremsdruck.CONSTANT = bremsdruck.MAX / resolution;
	feder_v.CONSTANT = feder_v.MAX / resolution;
	feder_h.CONSTANT = feder_h.MAX / resolution;

}

void Calculate_ACC_BRK(struct RL_sensor gas, struct RL_sensor brk, uint32_t ADC_RAW[]) {
//Send RAW
	uint32_t brk_mid = (ADC_RAW[brk.CHANNEL_LEFT] + ADC_RAW[brk.CHANNEL_RIGHT]) / 2;
	hcan1.pTxMsg->StdId = gas.CAN_ID;
	hcan1.pTxMsg->DLC = 6;
	hcan1.pTxMsg->Data[0] = ADC_RAW[gas.CHANNEL_LEFT] >> 8;
	hcan1.pTxMsg->Data[1] = ADC_RAW[gas.CHANNEL_LEFT] & 0x00ff;
	hcan1.pTxMsg->Data[2] = ADC_RAW[gas.CHANNEL_RIGHT] >> 8;
	hcan1.pTxMsg->Data[3] = ADC_RAW[gas.CHANNEL_RIGHT] & 0x00ff;
	hcan1.pTxMsg->Data[4] = brk_mid >> 8;
	hcan1.pTxMsg->Data[5] = brk_mid & 0x00ff;
	HAL_CAN_Transmit(&hcan1, 10);
}

void Calculate_FD(struct RL_sensor v, struct RL_sensor h) {
	uint32_t vr = ADC1_RAW[v.CHANNEL_RIGHT] * v.CONSTANT;
	uint32_t vl = ADC1_RAW[v.CHANNEL_LEFT] * v.CONSTANT;
	uint32_t hr = ADC1_RAW[h.CHANNEL_RIGHT] * h.CONSTANT;
	uint32_t hl = ADC1_RAW[h.CHANNEL_LEFT] * h.CONSTANT;
	hcan1.pTxMsg->StdId = v.CAN_ID;
	hcan1.pTxMsg->DLC = 4;
	hcan1.pTxMsg->Data[0] = vr;
	hcan1.pTxMsg->Data[1] = vl;
	hcan1.pTxMsg->Data[2] = hr;
	hcan1.pTxMsg->Data[3] = hl;
	HAL_CAN_Transmit(&hcan1, 10);
}

void Check_PIN(void) {
	uint32_t expo = 1;
	uint32_t ERROR_CODE = 0;
	for (int i = 0; i < 9; i++) {
		if (!(ADC1_RAW[i])) {
			ERROR_COUNT_RL[i]++;
			if (ERROR_COUNT_RL[i] >= 10) {
				ERROR_CODE = ERROR_CODE + expo;
			}
		}
		expo = expo * 10;
	}
	for (int i = 0; i < 6; i++) {
		if (!ADC2_RAW[i]) {
			ERROR_COUNT_S[i]++;
			if (ERROR_COUNT_S[i] >= 10) {
				ERROR_CODE = ERROR_CODE + expo;
			}
		}
		expo = expo * 10;
	}
	hcan1.pTxMsg->StdId = 404;
	hcan1.pTxMsg->DLC = 2;
	hcan1.pTxMsg->Data[0] = ERROR_CODE >> 8;
	hcan1.pTxMsg->Data[1] = ERROR_CODE & 0x00ff;
	HAL_CAN_Transmit(&hcan1, 10);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler */
	/* User can add his own implementation to report the HAL error return state */
	while (1) {
	}
  /* USER CODE END Error_Handler */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
	 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
