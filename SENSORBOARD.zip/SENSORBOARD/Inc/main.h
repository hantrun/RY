
#include "canid.h"
#include "stm32f4xx_hal.h"
#ifndef SENSORS_H_
#define SENSORS_H_
/*
 * Prototypes
 */

/**
 * RL_sensor struct: contains important information about the sensors which are in front/back or left/right
 * @CAN_ID: CAN_ID from "canid.h"
 * @CHANNEL_RANK: Rank of the multichannel ADC
 * @RAWTODATA: Constant to calculate Data from RAW
 *
 */
struct RL_sensor{
	uint32_t CAN_ID;
	uint32_t CHANNEL_RIGHT;
	uint32_t CHANNEL_LEFT;

	float MAX;
	float CONSTANT;
	int RAW;
};

/**
 * S_sensor struct: used vor single sensors
 * @CAN_ID: canid from "canid.h
 * @CHANNEL: RAWDATA channel
 * @CONSTANT: constant to calculate data from raw
 *
 */
struct S_sensor{
	uint32_t CAN_ID;
	uint32_t CHANNEL;
	float MAX;
	float CONSTANT;
};
//extern struct RL_sensor;
//extern struct RL_sensor gas				= {CAN_ID_SENSOR_ACC_BRK, 0, 1, 105, 0}; //gas
//extern struct RL_sensor bremsdruck 		= {0, 2, 3, 250, 0}; //bremsdruck vorne=recht
//extern struct RL_sensor feder_v 		= {0, 5, 6, 75, 0}; //feder vorne
//extern struct RL_sensor feder_h 		= {0, 7, 8, 75, 0}; //feder hinten
//extern struct S_sensor lenkung 			= {0, 2, 0, 0}; //lenkwinkel
//
////temperature sensors
//extern struct S_sensor temp1 			= {0, 0, 0, 0};
//extern struct S_sensor temp2 			= {0, 1, 0, 0};
//extern struct S_sensor temp3 			= {0, 2, 0, 0};
//extern struct S_sensor temp4 			= {0, 3, 0, 0};
//extern struct S_sensor temp5 			= {0, 4, 0, 0};
//extern struct S_sensor temp6 			= {0, 5, 0, 0};

#endif /* SENSORS_H_ */
